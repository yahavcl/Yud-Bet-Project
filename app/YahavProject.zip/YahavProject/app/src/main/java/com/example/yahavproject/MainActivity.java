package com.example.yahavproject;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView lv_countries_list;
    ArrayList<Country> countryArr = new ArrayList<>();
    CountryAdapter countryAdapter;
    EditText user_word_is;
    Button search_a_word;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Write a message to the database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("message");

        myRef.setValue("good morning");
        setContentView(R.layout.activity_main);
        lv_countries_list = (ListView)findViewById(R.id.lv_countries_list);
        user_word_is = (EditText)findViewById(R.id.user_word_is);
        search_a_word = (Button)findViewById(R.id.search_a_word);



        Country country1 = new Country("Israel", "Hebrew", R.drawable.israel);
        Country country2 = new Country("Italy", "Italian", R.drawable.italy);
        Country country3 = new Country("Canada", "English", R.drawable.canada);
        Country country4 = new Country("Germany", "German", R.drawable.germany);

        countryArr.add(country1);
        countryArr.add(country2);
        countryArr.add(country3);
        countryArr.add(country4);

        countryAdapter = new CountryAdapter(this, 0, 0, countryArr);

        lv_countries_list.setAdapter(countryAdapter);




    }

}