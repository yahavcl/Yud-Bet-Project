package com.example.yahavproject;

public class Country {
    private String name;
    private String language;
    private int flag;

    public Country(String name, String language, int flag) {
        this.name = name;
        this.language = language;
        this.flag = flag;
    }

    public String getName() {
        return name;
    }

    public String getLanguage() {
        return language;
    }

    public int getFlag() {
        return flag;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }


}
