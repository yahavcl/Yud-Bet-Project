package com.example.yahavproject;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        if (("android.intent.action.BOOT_COMPLETED").equals(intent.getAction())) {
            Intent serviceIntent = new Intent("com.example.yahavproject.FireBaseNotification_service");

            context.startService(serviceIntent);
        }

        // TODO: This method is called when the BroadcastReceiver is receiving
        // an Intent broadcast.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}