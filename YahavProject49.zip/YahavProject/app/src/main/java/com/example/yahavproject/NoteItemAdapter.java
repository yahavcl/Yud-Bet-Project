/*package com.example.yahavproject;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class NoteItemAdapter extends RecyclerView.Adapter<NoteItemAdapter.MyViewHolder> {

    Context context;
    Activity activity;
    List<NoteItem> objects;

    public NoteItemAdapter(Context context, Activity activity, List<NoteItem> objects) {
        this.context = context;
        this.activity = activity;
        this.objects = objects;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = ((Activity)context).getLayoutInflater();
        View view = layoutInflater.inflate(R.layout.item_note, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        holder.titleNote.setText(objects.get(position).getNote_title());
        holder.timeNote.setText(objects.get(position).getNote_time());

    }

    @Override
    public int getItemCount() {
        return objects.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView titleNote;
        TextView timeNote;
        LinearLayout noteLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            titleNote = (TextView)itemView.findViewById(R.id.tv_title_note);
            timeNote = (TextView)itemView.findViewById(R.id.tv_time_note);
            noteLayout = (LinearLayout)itemView.findViewById(R.id.lo_item_note);
        }
    }

}*/
