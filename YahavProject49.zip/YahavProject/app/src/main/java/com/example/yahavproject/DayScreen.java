/*package com.example.yahavproject;

import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class DayScreen {
    public String dayName;
    public ListView eventsList;
    public FloatingActionButton addEvent;
    public int dayLayout;

    public DayScreen (){}

    public DayScreen (String dayName, ListView eventsList, FloatingActionButton addEvent) {
        this.dayName = dayName;
        this.eventsList = eventsList;
        this.addEvent = addEvent;
    }

    public DayScreen (String dayName, int dayLayout) {
        this.dayName = dayName;
        this.dayLayout = dayLayout;
    }

    public String getDayName() {
        return dayName;
    }

    public void setDayName(String dayName) {
        this.dayName = dayName;
    }

    public ListView getEventsList() {
        return eventsList;
    }

    public void setEventsList(ListView eventsList) {
        this.eventsList = eventsList;
    }

    public FloatingActionButton getAddEvent() {
        return addEvent;
    }

    public void setAddEvent(FloatingActionButton addEvent) {
        this.addEvent = addEvent;
    }

    public int getDayLayout() {
        return dayLayout;
    }

    public void setDayLayout(int dayLayout) {
        this.dayLayout = dayLayout;
    }
}*/
