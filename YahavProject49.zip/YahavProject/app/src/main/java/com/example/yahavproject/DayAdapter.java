package com.example.yahavproject;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;
/*
public class DayAdapter extends ArrayAdapter<Day> {
    Context context;
    List<Day> objects;

    public DayAdapter(@NonNull Context context, int resource, int textViewResourceId, @NonNull List<Day> objects) {
        super(context, resource, textViewResourceId, objects);
        this.context = context;
        this.objects = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = ((Activity)context).getLayoutInflater();
        View view = layoutInflater.inflate(R.layout.one_line, parent, false);

        TextView tvName = (TextView)view.findViewById(R.id.name);
        Button buttonArrow = (Button) view.findViewById(R.id.arrow);

        Day temp = objects.get(position);

        tvName.setText(String.valueOf(temp.getName()));

        buttonArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                temp.getArrow().setOnClickListener(this);


            }
        });
        //buttonArrow.setOnClickListener(this);


        return view;

    }

    @Override
    public void onClick(View view) {



public class DayAdapter extends ArrayAdapter<Day>{

    Context context;
    List<Day> objects;

    public DayAdapter(@NonNull Context context, int resource, int textViewResourceId, @NonNull List<Day> objects) {
        super(context, resource, textViewResourceId, objects);
        this.context = context;
        this.objects = objects;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        ViewHolder if_view_holder_is_not_null = null;
        if(convertView == null){
            LayoutInflater inflater = LayoutInflater.from(getContext());
            View view = inflater.inflate(R.layout.one_line, parent, false);
            ViewHolder viewHolder = new ViewHolder();
            viewHolder.viewHolderTextView = (TextView)convertView.findViewById(R.id.tv_oneLine_name);
            viewHolder.viewHolderButton = (Button) convertView.findViewById(R.id.btn_oneLine_arrow);
            viewHolder.viewHolderButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(getContext(),"button of list line number "+position +" was clicked", Toast.LENGTH_SHORT).show();
                }
            });

            convertView.setTag(viewHolder);
        }
        else{
            if_view_holder_is_not_null = (ViewHolder)convertView.getTag();
            if_view_holder_is_not_null.viewHolderTextView.setText("");
        }
        return convertView;
    }
}


*/


