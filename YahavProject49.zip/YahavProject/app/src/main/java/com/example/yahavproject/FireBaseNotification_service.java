/*package com.example.yahavproject;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.NotificationCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class FireBaseNotification_service extends Service {

    //Date currentTime = Calendar.getInstance().getTime();

    //String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
    //String currentDay = new SimpleDateFormat("EEE", Locale.getDefault()).format(new Date());

    Handler handler = new Handler();

    String currentTime = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference();
    Query q;
    NotificationCompat.Builder builder;
    NotificationManager manager;
    String userName;
    NoteItem noteItem = new NoteItem("stam", "10:13", "", R.color.black);
    public FireBaseNotification_service() {
    }

    @Override
    public void onCreate() {
        super.onCreate();
        userName=LoginActivity.nowUsingThisPhone.email;
    }



    @SuppressLint("WrongConstant")
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        builder = new NotificationCompat.Builder(this)
                .setSmallIcon(R.drawable.common_google_signin_btn_icon_dark)
                .setContentTitle("app NAME")
                .setContentText(currentTime)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setPriority(NotificationCompat.PRIORITY_MAX);

        int NOTIFICATION_ID = 12345;


        Intent notification_intent = new Intent(this, MainActivity.class);


        PendingIntent contentIntent = PendingIntent
                .getActivity(this, 0, notification_intent, PendingIntent.FLAG_UPDATE_CURRENT);


        manager = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);

        builder.setContentIntent(contentIntent);



        q = myRef.child("my app users").child(userName)
                .child("days").child("Sunday").child("NOTES").orderByValue();

        q.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot dst : dataSnapshot.getChildren()) {
                   // noteItem = dst.getValue(NoteItem.class);
                    if ((noteItem.note_time).equals(currentTime)) {
                        builder.setContentText("יש לך התראה חדשה");
                        manager.notify(NOTIFICATION_ID, builder.build());
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });




        return Service.START_STICKY;

        //return super.onStartCommand(intent,flags,startId);
    }
    @Override
    public void onDestroy() {
        super.onDestroy();

    }
    @Override
    public boolean onUnbind(Intent intent) {
        return super.onUnbind(intent);
    }
    public void onStop(){
    }





    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}*/