/*package com.example.yahavproject;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class CountryAdapter extends ArrayAdapter <Country> {
    Context context;
    List<Country> objects;
    public CountryAdapter(@NonNull Context context, int resource, int textViewResourceId, @NonNull List<Country> objects) {
        super(context, resource, textViewResourceId, objects);
        this.context = context;
        this.objects = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = ((Activity)context).getLayoutInflater();
        View view = layoutInflater.inflate(R.layout.one_line, parent, false);

        TextView tvCountryName = (TextView)view.findViewById(R.id.day);
        TextView tvCountryLanguach = (TextView)view.findViewById(R.id.language);
        ImageView ivCountryFlag=(ImageView)view.findViewById(R.id.flag);

        Country temp = objects.get(position);
        ivCountryFlag.setImageResource(temp.getFlag());
        tvCountryName.setText(String.valueOf(temp.getName()));
        tvCountryLanguach.setText(temp.getLanguage());
        return view;
    }
}*/
