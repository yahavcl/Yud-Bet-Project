package com.example.yahavproject;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView lv_day_list;
    ArrayList<Day> dayList;
  //  DayAdapter dayAdapter;

    Button arrowSun;
    Button arrowMon;
    Button arrowTue;
    Button arrowWed;
    Button arrowThu;
    Button arrowFri;
    Button arrowSat;

    Button btn_log_out;

    FirebaseDatabase database;
    DatabaseReference myRef;
    //static User thisUser;

    Intent my_notification_service;
    Intent try_service;
    //MyBroadcastReceiver_NetworkConnectivity receiver_networkConnectivity = new MyBroadcastReceiver_NetworkConnectivity();

    //static String userEmail;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //userEmail = LoginActivity.user_email;

        //LoginActivity.nowUsingThisPhone = thisUser;

        lv_day_list = (ListView) findViewById(R.id.lv_day_list);

        btn_log_out = (Button)findViewById(R.id.btn_log_out);

        /*my_notification_service = new Intent(MainActivity.this, FireBaseNotification_service.class);
        startService(my_notification_service);*/
        try_service = new Intent(MainActivity.this, TryService.class);
        startService(try_service);

        btn_log_out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences preferences = getSharedPreferences("checkbox", MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("remember", "false");
                editor.apply();
                finish();

                LoginActivity.rememberIsOn = false;

            }
        });



        Day sunday = new Day("SUNDAY", arrowSun);
        Day monday = new Day("MONDAY", arrowMon);
        Day tuesday = new Day("TUESDAY", arrowTue);
        Day wednesday = new Day("WEDNESDAY", arrowWed);
        Day thursday = new Day("THURSDAY", arrowThu);
        Day friday = new Day("FRIDAY", arrowFri);
        Day saturday = new Day("SATURDAY", arrowSat);


        dayList = new ArrayList<Day>();
        dayList.add(sunday);
        dayList.add(monday);
        dayList.add(tuesday);
        dayList.add(wednesday);
        dayList.add(thursday);
        dayList.add(friday);
        dayList.add(saturday);

        //lv_day_list = (ListView)findViewById(R.id.lv_day_list);
        lv_day_list.setAdapter(new MyListAdapter(this, R.layout.one_line, dayList));

        //receiver_networkConnectivity.onReceive(this, this.getIntent());


    }

       private class MyListAdapter extends ArrayAdapter<Day> {

        //private int mySpecialLayout;
        public MyListAdapter(Context context, int resource, List<Day> objects) {
            super(context, resource, objects);

            //mySpecialLayout = resource;
        }

        @SuppressLint("SetTextI18n")
        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            ViewHolder if_view_holder_is_not_null = null;
            if(convertView == null){
                LayoutInflater inflater = LayoutInflater.from(getContext());
                convertView = inflater.inflate(R.layout.one_line,parent,false);
                ViewHolder viewHolder = new ViewHolder();
                viewHolder.viewHolderTextView = (TextView)convertView.findViewById(R.id.tv_title_sun);
                viewHolder.viewHolderButton = (Button) convertView.findViewById(R.id.btn_oneLine_arrow);

                Day temp = dayList.get(position);

                viewHolder.viewHolderTextView.setText((temp.getName()));

                viewHolder.viewHolderButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //Toast.makeText(getContext(),"button of list LINE number "+position +" was clicked", Toast.LENGTH_SHORT).show();
                        //receiver_networkConnectivity.onReceive(MainActivity.this, MainActivity.this.getIntent());

                        if (position == 0) {
                            //myRef.child("Sunday").setValue(SundayActivity.class);
                            startActivity(new Intent(MainActivity.this, SundayActivity.class));
                        }

                        else if (position == 1) {
                           // myRef.child("Monday").setValue(MondayActivity.class);
                            startActivity(new Intent(MainActivity.this, MondayActivity.class));
                        }

                        else if (position == 2) {
                          //  myRef.child("Tuesday").setValue(TuesdayActivity.class);
                            startActivity(new Intent(MainActivity.this, TuesdayActivity.class));
                        }

                        else if (position == 3) {
                         //   myRef.child("Wednesday").setValue(WednesdayActivity.class);
                            startActivity(new Intent(MainActivity.this, WednesdayActivity.class));
                        }

                        else if (position == 4) {
                          //  myRef.child("Thursday").setValue(ThursdayActivity.class);
                            startActivity(new Intent(MainActivity.this, ThursdayActivity.class));
                        }

                        else if (position == 5) {
                        //    myRef.child("Friday").setValue(FridayActivity.class);
                            startActivity(new Intent(MainActivity.this, FridayActivity.class));
                        }

                        else {
                        //    myRef.child("Saturday").setValue(SaturdayActivity.class);
                            startActivity(new Intent(MainActivity.this, SaturdayActivity.class));
                        }


                    }
                });

                convertView.setTag(viewHolder);
            }
            else{
                if_view_holder_is_not_null = (ViewHolder)convertView.getTag();
                //if_view_holder_is_not_null.viewHolderTextView.setText(""+position);
            }
            return convertView;
        }
    }

    public class ViewHolder{
        TextView viewHolderTextView;
        Button viewHolderButton;
    }

    /*@Override
    public void onCreate(@Nullable Bundle savedInstanceState, @Nullable PersistableBundle persistentState) {
        super.onCreate(savedInstanceState, persistentState);
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(receiver_networkConnectivity, filter);


    }*/

    /*@Override
    protected void onDestroy() {
        super.onDestroy();
        if (LoginActivity.rememberIsOn == true) {

            //my_notification_service = new Intent();
            startService(my_notification_service);


        }

        //unregisterReceiver(receiver_networkConnectivity);
    }*/




}

